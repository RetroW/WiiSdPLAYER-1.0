WiiSdPLAYER V1.0 by RetroW and Queezyned
wELCOME AND THANKS FOR DOWNLOADING! WARNING: HAVE BOOTMII OR PRIILOADER
TO AVOID A BRICK! This program does NOT appcect USBs. please use
USB loader GX if so. If you paid for this software, you have been
scammed AND SHOULD DEMAND YOUR MONEY BACK NOW!!! The creators,
RetroW and Queezyned are not responsible for any damage or bricks
caused by YOU not being careful. it would be YOUR fault if so!!!
Put the WiiSdPLAYER folder in the apps folder in your SD card. contact
us on github if: black screen, Dsi error, Error 002. and hopefully the
next version will fix it.
+-----   +
+        +    _----
+        +   _     -   _        -------- +             +    -
+-----   +  -      -   _        +      +  +           +     -
+        +-        -            +      +   +         +      -
+        +         -            +      +    +       +       -
+        +         -            +      +     +     +        -
+        +         -            +      +      +   +         -
+        +         -            +      +       + +          
+-----   +         -   +        +------+        +           +
                       +                       +
                       +                      +
                    ++++                     +